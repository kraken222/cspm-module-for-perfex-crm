<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="panel_s">
                    <div class="panel-body">
                        <div class="_buttons">
                            <h3 class="pull-left">
                                <i class="fa fa-shield"></i> <?php echo $title; ?>
                            </h3>
                            <div class="pull-right">
                                <button class="btn btn-default" onclick="location.href='<?php echo admin_url('cspm/settings'); ?>'">
                                    <i class="fa fa-cog"></i> Settings
                                </button>
                                <button class="btn btn-info" onclick="location.href='<?php echo admin_url('cspm/view_results'); ?>'">
                                    <i class="fa fa-history"></i> View Results
                                </button>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <hr class="hr-panel-heading" />

                        <?php if (isset($no_results) && $no_results): ?>
                            <!-- No Results View -->
                            <div class="alert alert-warning">
                                <i class="fa fa-exclamation-triangle"></i> No scan results available. Please run a scan first.
                            </div>
                            <div class="text-center">
                                <a href="<?php echo admin_url('cspm/settings'); ?>" class="btn btn-primary">
                                    <i class="fa fa-play"></i> Start New Scan
                                </a>
                            </div>
                        
                        <?php elseif (isset($scan_details) && isset($findings)): ?>
                            <!-- Results View -->
                            <div class="row">
                                <div class="col-md-12">
                                    <h4>Scan ID: <?php echo $scan_id; ?></h4>
                                    <p>Completed: <?php echo date('F j, Y g:i A', strtotime($scan_details->completed_at)); ?></p>
                                </div>
                            </div>

                            <!-- Summary Cards -->
                            <div class="row">
                                <div class="col-md-3 col-sm-6">
                                    <div class="widget-stats">
                                        <div class="widget-stats-icon bg-blue">
                                            <i class="fa fa-check-circle"></i>
                                        </div>
                                        <div class="widget-stats-info">
                                            <h4><?php echo $scan_details->total_checks; ?></h4>
                                            <p>Total Checks</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="widget-stats">
                                        <div class="widget-stats-icon bg-success">
                                            <i class="fa fa-shield"></i>
                                        </div>
                                        <div class="widget-stats-info">
                                            <h4><?php echo $scan_details->compliant_checks; ?></h4>
                                            <p>Passed</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="widget-stats">
                                        <div class="widget-stats-icon bg-danger">
                                            <i class="fa fa-times-circle"></i>
                                        </div>
                                        <div class="widget-stats-info">
                                            <h4><?php echo $scan_details->non_compliant_checks; ?></h4>
                                            <p>Failed</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="widget-stats">
                                        <div class="widget-stats-icon bg-info">
                                            <i class="fa fa-percentage"></i>
                                        </div>
                                        <div class="widget-stats-info">
                                            <h4><?php echo $scan_details->compliance_percentage; ?>%</h4>
                                            <p>Compliance</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Findings Table -->
                            <div class="row mtop20">
                                <div class="col-md-12">
                                    <h4>Compliance Findings</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped dt-table">
                                            <thead>
                                                <tr>
                                                    <th>Resource</th>
                                                    <th>Check</th>
                                                    <th>Status</th>
                                                    <th>Severity</th>
                                                    <th>Framework</th>
                                                    <th>Region</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($findings as $finding): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($finding->resource_id); ?></strong>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($finding->resource_type); ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($finding->check_name); ?></td>
                                                    <td>
                                                        <?php 
                                                        $status_class = ($finding->status === 'PASS') ? 'success' : 'danger';
                                                        ?>
                                                        <span class="label label-<?php echo $status_class; ?>"><?php echo $finding->status; ?></span>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        $severity_class = 'default';
                                                        switch($finding->severity) {
                                                            case 'CRITICAL': $severity_class = 'danger'; break;
                                                            case 'HIGH': $severity_class = 'warning'; break;
                                                            case 'MEDIUM': $severity_class = 'info'; break;
                                                            case 'LOW': $severity_class = 'success'; break;
                                                        }
                                                        ?>
                                                        <span class="label label-<?php echo $severity_class; ?>"><?php echo $finding->severity; ?></span>
                                                    </td>
                                                    <td><code><?php echo $finding->framework; ?></code></td>
                                                    <td><?php echo $finding->region; ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Assets Table -->
                            <?php if (!empty($assets)): ?>
                            <div class="row mtop20">
                                <div class="col-md-12">
                                    <h4>Discovered Assets</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped dt-table">
                                            <thead>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Resource ID</th>
                                                    <th>Name</th>
                                                    <th>Region</th>
                                                    <th>Discovered</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($assets as $asset): ?>
                                                <tr>
                                                    <td><?php echo $asset->resource_type; ?></td>
                                                    <td><code><?php echo htmlspecialchars($asset->resource_id); ?></code></td>
                                                    <td><?php echo htmlspecialchars($asset->resource_name); ?></td>
                                                    <td><?php echo $asset->region; ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($asset->discovered_at)); ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                        <?php else: ?>
                            <!-- Main Scanner Interface -->
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Provider Selection -->
                                    <div class="btn-group btn-group-lg mtop15 mbot15" role="group">
                                        <button type="button" class="btn btn-primary active" onclick="selectProvider('aws')">
                                            <i class="fab fa-aws"></i> AWS
                                        </button>
                                        <button type="button" class="btn btn-default" onclick="selectProvider('gcp')" disabled>
                                            <i class="fab fa-google"></i> GCP (Coming Soon)
                                        </button>
                                        <button type="button" class="btn btn-default" onclick="selectProvider('azure')" disabled>
                                            <i class="fab fa-microsoft"></i> Azure (Coming Soon)
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Scan Form -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customer" class="control-label">Customer <span class="text-danger">*</span></label>
                                        <select id="customer" class="form-control selectpicker" data-live-search="true">
                                            <option value="digiALERT">digiALERT</option>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="account_name" class="control-label">Account/Project Name</label>
                                        <input type="text" id="account_name" class="form-control" placeholder="Test Account" value="Test Account">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="access_key" class="control-label">AWS Access Key <span class="text-danger">*</span></label>
                                        <input type="text" id="access_key" class="form-control" placeholder="AKIA..." required>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="saved_credentials" class="control-label">Saved Credentials</label>
                                        <select id="saved_credentials" class="form-control">
                                            <option value="">Select saved credentials or enter new</option>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="secret_key" class="control-label">AWS Secret Key <span class="text-danger">*</span></label>
                                        <input type="password" id="secret_key" class="form-control" placeholder="••••••••••••••••••••" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="region" class="control-label">AWS Region</label>
                                        <select id="region" class="form-control">
                                            <option value="us-east-1">US East (N. Virginia)</option>
                                            <option value="us-west-2">US West (Oregon)</option>
                                            <option value="eu-west-1">EU (Ireland)</option>
                                            <option value="ap-southeast-1">Asia Pacific (Singapore)</option>
                                            <option value="ap-south-1">Asia Pacific (Mumbai)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="checkbox">
                                        <input type="checkbox" id="save_credentials">
                                        <label for="save_credentials">Save these credentials for future use</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mtop20">
                                <div class="col-md-12">
                                    <button class="btn btn-primary" onclick="startScan()">
                                        <i class="fa fa-play"></i> Start AWS Compliance Scan
                                    </button>
                                    <button class="btn btn-warning" onclick="testConnection()">
                                        <i class="fa fa-plug"></i> Test Connection
                                    </button>
                                    <button class="btn btn-info" onclick="viewLatestResults()">
                                        <i class="fa fa-chart-bar"></i> Latest Results
                                    </button>
                                </div>
                            </div>

                            <!-- Status Messages -->
                            <div class="row mtop20">
                                <div class="col-md-12">
                                    <div id="scan-status" class="alert alert-info" style="display:none;">
                                        <i class="fa fa-spinner fa-spin"></i> <strong>Scanning...</strong> Please wait while we analyze your AWS environment. This may take several minutes.
                                    </div>
                                    
                                    <div id="error-message" class="alert alert-danger" style="display:none;"></div>
                                    <div id="success-message" class="alert alert-success" style="display:none;"></div>
                                </div>
                            </div>

                            <!-- Results Container -->
                            <div id="results-section" class="row mtop20"></div>

                            <!-- Recent Scans -->
                            <?php if (!empty($recent_scans)): ?>
                            <div class="row mtop20">
                                <div class="col-md-12">
                                    <h4>Recent Scans</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Scan ID</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Total Checks</th>
                                                    <th>Compliance %</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($recent_scans as $scan): ?>
                                                <tr>
                                                    <td><code><?php echo substr($scan->scan_id, 0, 20); ?>...</code></td>
                                                    <td><?php echo date('M d, Y g:i A', strtotime($scan->started_at)); ?></td>
                                                    <td>
                                                        <span class="label label-<?php echo ($scan->scan_status == 'completed') ? 'success' : 'warning'; ?>">
                                                            <?php echo ucfirst($scan->scan_status); ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo $scan->total_checks; ?></td>
                                                    <td>
                                                        <div class="progress" style="margin: 0;">
                                                            <div class="progress-bar progress-bar-<?php echo ($scan->compliance_percentage >= 80) ? 'success' : (($scan->compliance_percentage >= 60) ? 'warning' : 'danger'); ?>" 
                                                                 style="width: <?php echo $scan->compliance_percentage; ?>%">
                                                                <?php echo $scan->compliance_percentage; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo admin_url('cspm/view_results/' . $scan->scan_id); ?>" class="btn btn-xs btn-default">
                                                            <i class="fa fa-eye"></i> View
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script>
var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

function startScan() {
    // Get form values
    var accessKey = $('#access_key').val().trim();
    var secretKey = $('#secret_key').val().trim();
    var accountName = $('#account_name').val().trim() || 'Test Account';
    var region = $('#region').val();
    
    // Debug log
    console.log('Starting scan with:', {
        access_key_length: accessKey.length,
        secret_key_length: secretKey.length,
        account_name: accountName,
        region: region
    });
    
    // Validate
    if (!accessKey || !secretKey) {
        showError('Please enter both AWS Access Key and Secret Key');
        return;
    }
    
    // Hide previous messages
    $('#error-message').hide();
    $('#success-message').hide();
    $('#results-section').html('');
    
    // Show loading
    $('#scan-status').show();
    
    // Prepare data
    var postData = {
        access_key: accessKey,
        secret_key: secretKey,
        account_name: accountName,
        region: region
    };
    
    // Add CSRF token
    postData[csrfName] = csrfHash;
    
    // Send AJAX request
    $.ajax({
        url: '<?php echo admin_url("cspm/ajax_scan"); ?>',
        type: 'POST',
        dataType: 'json',
        data: postData,
        success: function(response) {
            $('#scan-status').hide();
            
            // Update CSRF token for next request
            if (response.csrfHash) {
                csrfHash = response.csrfHash;
            }
            
            if (response.status === 'success') {
                showSuccess('Scan completed successfully! Scan ID: ' + response.scan_id);
                displayResults(response);
            } else {
                showError(response.message || 'Scan failed');
                
                // Show troubleshooting tips
                var troubleshooting = '<br><br><strong>Troubleshooting:</strong><ul>' +
                    '<li>Check if Python scanner is running on port 5001</li>' +
                    '<li>Verify AWS credentials are correct</li>' +
                    '<li>Ensure network connectivity to 143.110.240.247:5001</li>' +
                    '<li>Check browser console (F12) for detailed errors</li></ul>';
                $('#error-message').append(troubleshooting);
            }
        },
        error: function(xhr, status, error) {
            $('#scan-status').hide();
            console.error('AJAX Error:', xhr);
            
            var errorMsg = 'Connection failed: ' + error;
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMsg = xhr.responseJSON.message;
            } else if (xhr.responseText) {
                console.log('Response Text:', xhr.responseText);
                // Check if it's HTML error page
                if (xhr.responseText.indexOf('<!DOCTYPE') > -1) {
                    errorMsg = 'Server error - check console for details';
                }
            }
            
            showError(errorMsg);
        }
    });
}

function testConnection() {
    window.open('<?php echo admin_url("cspm/test_connection"); ?>', '_blank');
}

function viewLatestResults() {
    window.location.href = '<?php echo admin_url("cspm/view_results"); ?>';
}

function selectProvider(provider) {
    alert('Only AWS is currently supported. ' + provider.toUpperCase() + ' support coming soon!');
}

function showError(message) {
    $('#error-message').html('<i class="fa fa-times-circle"></i> <strong>Scan Failed</strong><br>' + message).show();
    $('html, body').animate({
        scrollTop: $('#error-message').offset().top - 100
    }, 500);
}

function showSuccess(message) {
    $('#success-message').html('<i class="fa fa-check-circle"></i> <strong>Success!</strong> ' + message).show();
}

function displayResults(data) {
    var html = '<div class="col-md-12">';
    html += '<h3>Scan Results</h3>';
    
    if (data.summary_html) {
        html += data.summary_html;
    }
    
    if (data.findings_html) {
        html += '<h4 class="mtop20">Compliance Findings (' + data.findings_count + ')</h4>';
        html += data.findings_html;
    }
    
    if (data.assets_html) {
        html += '<h4 class="mtop20">Discovered Assets (' + data.assets_count + ')</h4>';
        html += data.assets_html;
    }
    
    html += '<div class="mtop20">';
    html += '<a href="<?php echo admin_url("cspm/view_results/"); ?>' + data.scan_id + '" class="btn btn-success">';
    html += '<i class="fa fa-chart-bar"></i> View Full Report</a>';
    html += '</div>';
    html += '</div>';
    
    $('#results-section').html(html);
    
    // Scroll to results
    $('html, body').animate({
        scrollTop: $('#results-section').offset().top - 100
    }, 500);
}
</script>

<?php init_tail(); ?>