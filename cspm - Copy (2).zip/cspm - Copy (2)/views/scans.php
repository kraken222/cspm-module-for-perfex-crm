<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8"><h4 class="no-margin"><?php echo $title; ?></h4></div>
              <div class="col-md-4 text-right">
                <a href="<?php echo admin_url('cspm/settings'); ?>" class="btn btn-default"><i class="fa fa-cog"></i> Settings</a>
              </div>
            </div>
            <hr class="hr-panel-heading"/>

            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr><th>Scan ID</th><th>Provider</th><th>Account</th><th>Status</th><th>Total</th><th>Passed</th><th>Failed</th><th>Started</th><th>Completed</th><th>Action</th></tr>
                </thead>
                <tbody id="tbody">
                  <?php if(!empty($scans)): foreach($scans as $r): ?>
                    <tr id="row_<?php echo html_escape($r['scan_id']); ?>">
                      <td><?php echo html_escape($r['scan_id']); ?></td>
                      <td><?php echo strtoupper(html_escape($r['cloud_provider'])); ?></td>
                      <td><?php echo html_escape($r['account_name']); ?></td>
                      <td class="status"><?php echo html_escape($r['scan_status']); ?></td>
                      <td class="total"><?php echo (int)$r['total_checks']; ?></td>
                      <td class="pass"><?php echo (int)$r['compliant_checks']; ?></td>
                      <td class="fail"><?php echo (int)$r['non_compliant_checks']; ?></td>
                      <td><?php echo html_escape($r['started_at']); ?></td>
                      <td class="completed"><?php echo html_escape($r['completed_at']); ?></td>
                      <td><a class="btn btn-info btn-xs" href="<?php echo admin_url('cspm/view_result/'.$r['scan_id']); ?>">View</a></td>
                    </tr>
                  <?php endforeach; else: ?>
                    <tr><td colspan="10" class="text-center">No scans yet.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Autorefresh any "running" rows
  $('#tbody tr').each(function(){
    var id = $(this).attr('id'); if(!id) return;
    var scan_id = id.replace('row_','');
    var status = $(this).find('.status').text().trim().toLowerCase();
    if(status==='running'){ poll(scan_id); }
  });
  function poll(scan_id){
    var tries=0;
    (function tick(){
      $.getJSON('<?php echo admin_url('cspm/ajax_status/'); ?>'+scan_id,function(r){
        if(r && r.scan){
          var row = $('#row_'+scan_id);
          row.find('.status').text(r.scan.scan_status);
          row.find('.total').text(r.scan.total_checks||0);
          row.find('.pass').text(r.scan.compliant_checks||0);
          row.find('.fail').text(r.scan.non_compliant_checks||0);
          row.find('.completed').text(r.scan.completed_at||'');
          if(r.scan.scan_status!=='completed' && r.scan.scan_status!=='failed'){ schedule(); }
        } else { schedule(); }
      }).fail(schedule);
      function schedule(){ tries++; setTimeout(tick, Math.min(60000, 10000 + tries*5000)); }
    })();
  }
})();
</script>
<?php init_tail(); ?>
