<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8"><h4 class="no-margin"><?php echo $title; ?></h4></div>
              <div class="col-md-4 text-right">
                <a href="<?php echo admin_url('cspm/scans'); ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Scans</a>
              </div>
            </div>
            <hr class="hr-panel-heading"/>

            <div class="row">
              <div class="col-md-3">
                <ul class="list-unstyled mtop20">
                  <li><strong>Scan ID:</strong> <?php echo html_escape($summary['scan_id']); ?></li>
                  <li><strong>Provider:</strong> <?php echo strtoupper(html_escape($summary['cloud_provider'])); ?></li>
                  <li><strong>Account:</strong> <?php echo html_escape($summary['account_name']); ?></li>
                  <li><strong>Status:</strong> <?php echo html_escape($summary['scan_status']); ?></li>
                  <li><strong>Started:</strong> <?php echo html_escape($summary['started_at']); ?></li>
                  <li><strong>Completed:</strong> <?php echo html_escape($summary['completed_at']); ?></li>
                </ul>
              </div>
              <div class="col-md-9">
                <div class="row">
                  <div class="col-sm-3"><div class="panel panel-default"><div class="panel-body text-center"><div>Total</div><h3><?php echo (int)$summary['total_checks']; ?></h3></div></div></div>
                  <div class="col-sm-3"><div class="panel panel-default"><div class="panel-body text-center"><div>Compliant</div><h3><?php echo (int)$summary['compliant_checks']; ?></h3></div></div></div>
                  <div class="col-sm-3"><div class="panel panel-default"><div class="panel-body text-center"><div>Non-Compliant</div><h3><?php echo (int)$summary['non_compliant_checks']; ?></h3></div></div></div>
                  <div class="col-sm-3"><div class="panel panel-default"><div class="panel-body text-center"><div>Compliance %</div><h3><?php echo round((float)$summary['compliance_percentage'],2); ?>%</h3></div></div></div>
                </div>

                <h4>Top Findings</h4>
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead><tr><th>Severity</th><th>Check</th><th>Status</th><th>Resource</th><th>Found At</th></tr></thead>
                    <tbody>
                      <?php if(!empty($findings)): foreach($findings as $f): ?>
                        <tr>
                          <td><?php echo html_escape($f['severity']); ?></td>
                          <td><?php echo html_escape($f['check_name']); ?></td>
                          <td><?php echo html_escape($f['status']); ?></td>
                          <td><?php echo html_escape($f['resource_id']); ?></td>
                          <td><?php echo html_escape($f['found_at']); ?></td>
                        </tr>
                      <?php endforeach; else: ?>
                        <tr><td colspan="5" class="text-center">No findings recorded (or provider did not return detailed checks).</td></tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>

                <?php if(!empty($summary['raw_results'])): ?>
                  <h4>Raw Results (JSON)</h4>
                  <pre style="max-height:360px;overflow:auto;"><?php echo htmlspecialchars(is_string($summary['raw_results'])?$summary['raw_results']:json_encode($summary['raw_results'],JSON_PRETTY_PRINT)); ?></pre>
                <?php endif; ?>

              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
