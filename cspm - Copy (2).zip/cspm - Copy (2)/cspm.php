<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Cloud Security Posture Management (CSPM)
Description: Comprehensive AWS and Azure compliance scanning with multi-framework support  
Version: 1.0.0
Author: CSPM Team
*/

define('CSPM_MODULE_NAME', 'cspm');

hooks()->add_action('admin_init', 'cspm_permissions');
hooks()->add_action('admin_init', 'cspm_init_menu_items');

register_activation_hook(CSPM_MODULE_NAME, 'cspm_module_activation_hook');

$CI = & get_instance();



function cspm_module_activation_hook()

{

    $CI = &get_instance();

    require_once(__DIR__ . '/install.php');

}

register_language_files(CSPM_MODULE_NAME, [CSPM_MODULE_NAME]);

$CI = & get_instance();

$CI->load->helper(CSPM_MODULE_NAME . '/cspm');

function cspm_init_menu_items()
{
    $CI = &get_instance();
    
    if (staff_can('view', 'cspm')) {
        
      $CI->app_menu->add_sidebar_menu_item('cspm', [
            'name'     => _l('cspm'),
            'href'     => admin_url('cspm'),
            'icon'     => 'fa fa-shield',
            'position' => 35,
        ]);
        
        if (staff_can('delete', 'cspm')) {
            $CI->app_menu->add_sidebar_children_item('cspm', [
                'slug'     => 'cspm-credentials',
                'name'     => _l('cspm_settings'),
                'href'     => admin_url('cspm/settings'),
                'position' => 2,
            ]);
            
           
        }
        
       
    }
}



function cspm_permissions()
{
    $capabilities = [];

    $capabilities['capabilities'] = [
            'view'   => _l('permission_view'),
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
    ];

    register_staff_capabilities('cspm', $capabilities, _l('CSPM'));
}

?>