<?php
// Language strings for CSPM module

$lang['cspm_settings'] = 'Settings';
$lang['cspm'] = 'CSPM';

// Add other language strings as needed
?>
