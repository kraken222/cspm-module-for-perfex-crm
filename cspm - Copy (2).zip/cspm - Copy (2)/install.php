
defined('BASEPATH') or exit('No direct script access allowed');

$CI = &get_instance();

// Add permissions
if (!$CI->db->get_where('permissions', ['name' => 'cspm'])->row()) {
    $CI->db->insert('permissions', [
        'name' => 'cspm',
        'shortname' => 'cspm'
    ]);
}