<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cspm extends AdminController
{
    // POINT THIS TO YOUR FLASK PROWLER BACKEND (AWS)
    private $aws_backend_base = 'http://127.0.0.1:5001';

    public function __construct()
    {
        parent::__construct();
        if (!staff_can('view', 'cspm')) {
            access_denied('cspm');
        }
        $this->load->database();
        $this->load->helper(['url','security']);
        $this->load->model('Aws_model');
        $this->load->model('Azure_model');
        $this->load->model('Gcp_model');
    }

    /* ============================
     * PAGES
     * ============================ */
    public function settings()
    {
        $this->process_notifications(); // make sure completed scans notify
        $data['title']         = 'CSPM Scanner';
        $data['regions']       = $this->aws_regions();
        $data['recent_scans']  = $this->get_recent_scans(10);
        $data['saved_creds']   = $this->get_saved_credentials(); // generic credentials store (optional)
        $this->load->view('cspm_inline', $data);
    }

    public function scans()
    {
        $this->process_notifications();
        $data['title'] = 'All CSPM Scans';
        $data['scans'] = $this->get_recent_scans(200);
        $this->load->view('scans', $data);
    }

    public function view_result($scan_id)
    {
        $scan = $this->db->where('scan_id', $scan_id)->get('tblcspm_awsscan_results')->row_array();
        if (!$scan) {
            set_alert('warning', 'Scan not found.');
            redirect(admin_url('cspm/scans'));
            return;
        }
        $data['title']   = 'Scan Details';
        $data['summary'] = $scan;
        $data['findings']= $this->db->where('scan_id', $scan_id)
                           ->order_by('severity','DESC')
                           ->limit(1000)->get('tblcspm_awscompliance_findings')->result_array();
        $this->load->view('scan_details', $data);
    }

    /* ============================
     * AJAX – START SCANS
     * ============================ */

    // POST /admin/cspm/ajax_scan  (provider: aws|azure|gcp)
    public function ajax_scan()
    {
        header('Content-Type: application/json');
        try {
            if (!staff_can('view', 'cspm')) {
                echo json_encode(['status'=>'error','message'=>'Permission denied']); exit;
            }

            $provider   = strtolower(trim($this->input->post('provider')));
            $account    = $this->security->xss_clean($this->input->post('account_name')) ?: 'Cloud Account';
            $severity   = $this->security->xss_clean($this->input->post('severity')); // aws optional
            $region     = $this->security->xss_clean($this->input->post('region'));   // aws optional
            $save_creds = (bool)$this->input->post('save_creds');

            // Provider-specific credentials
            $aws_access = $this->security->xss_clean($this->input->post('aws_access_key'));
            $aws_secret = $this->security->xss_clean($this->input->post('aws_secret_key'));

            $az_tenant  = $this->security->xss_clean($this->input->post('azure_tenant_id'));
            $az_client  = $this->security->xss_clean($this->input->post('azure_client_id'));
            $az_secret  = $this->security->xss_clean($this->input->post('azure_client_secret'));
            $az_sub     = $this->security->xss_clean($this->input->post('azure_subscription_id'));

            $gcp_key    = $this->input->post('gcp_service_account_json'); // JSON text

            // (optional) store creds for convenience
            if ($save_creds) { $this->save_credentials_snapshot($provider, $_POST); }

            switch ($provider) {
                case 'aws':
                    // Create "running" row first (so UI updates immediately)
                    $scan_id = $this->Aws_model->insert_scan_running('aws', $account, $region ?: 'all');

                    // Fire the Flask backend (non-blocking expectation)
                    $payload = ['accountName' => $account];
                    if (!empty($severity)) $payload['severity'] = $severity;
                    $this->curl_post_json(rtrim($this->aws_backend_base,'/').'/api/compliance', $payload, 6);

                    echo json_encode([
                        'status'  => 'started',
                        'scan_id' => $scan_id,
                        'message' => 'AWS scan started. It may take more than an hour.'
                    ]); exit;

                case 'azure':
                    $scan_id = $this->Azure_model->start_scan($az_tenant, $az_client, $az_secret, $az_sub, $account);
                    echo json_encode([
                        'status'=>'started','scan_id'=>$scan_id,
                        'message'=>'Azure scan started with ScoutSuite. It may take more than an hour.'
                    ]); exit;

                case 'gcp':
                    $scan_id = $this->Gcp_model->start_scan($gcp_key, $account);
                    echo json_encode([
                        'status'=>'started','scan_id'=>$scan_id,
                        'message'=>'GCP scan started with ScoutSuite. It may take more than an hour.'
                    ]); exit;

                default:
                    echo json_encode(['status'=>'error','message'=>'Unknown provider']); exit;
            }
        } catch (Exception $e) {
            echo json_encode(['status'=>'error','message'=>$e->getMessage()]); exit;
        }
    }

    // GET /admin/cspm/ajax_status/{scan_id}
    public function ajax_status($scan_id)
    {
        header('Content-Type: application/json');
        $scan = $this->db->where('scan_id',$scan_id)->get('tblcspm_awsscan_results')->row_array();
        if (!$scan) { echo json_encode(['status'=>'not_found']); return; }
        echo json_encode(['status'=>'ok','scan'=>$scan]);
    }

    // GET /admin/cspm/ajax_latest?limit=10
    public function ajax_latest()
    {
        header('Content-Type: application/json');
        $limit = (int)($this->input->get('limit') ?: 10);
        echo json_encode(['status'=>'ok','rows'=>$this->get_recent_scans($limit)]);
    }

    /* ============================
     * UTIL / NOTIFICATIONS
     * ============================ */

    private function get_recent_scans($limit = 50)
    {
        $this->db->order_by('started_at','DESC');
        $this->db->limit($limit);
        return $this->db->get('tblcspm_awsscan_results')->result_array() ?: [];
    }

    private function process_notifications()
    {
        // notify for completed scans without notification mark
        if (!$this->db->table_exists('tblcspm_scan_notify')) {
            $this->db->query("CREATE TABLE IF NOT EXISTS `tblcspm_scan_notify`(
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `scan_id` VARCHAR(191) UNIQUE,
                `notified_at` DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        }

        $completed = $this->db->query("
           SELECT r.* FROM tblcspm_awsscan_results r
           LEFT JOIN tblcspm_scan_notify n ON n.scan_id = r.scan_id
           WHERE r.scan_status='completed' AND n.scan_id IS NULL
           ORDER BY r.completed_at DESC LIMIT 50
        ")->result_array();

        if (!$completed) return;

        $staff = $this->db->select('staffid')->from(db_prefix().'staff')->where('active',1)->get()->result_array();
        foreach ($completed as $row) {
            $link = 'cspm/view_result/'.$row['scan_id'];
            foreach ($staff as $s) {
                $this->db->insert(db_prefix().'notifications', [
                    'description' => 'CSPM scan completed for '.$row['account_name'].' ['.strtoupper($row['cloud_provider']).']',
                    'touserid'    => (int)$s['staffid'],
                    'fromuserid'  => get_staff_user_id() ?: 0,
                    'link'        => $link,
                    'date'        => date('Y-m-d H:i:s'),
                    'isread'      => 0,
                ]);
            }
            $this->db->insert('tblcspm_scan_notify', [
                'scan_id'=>$row['scan_id'],'notified_at'=>date('Y-m-d H:i:s')
            ]);
        }
    }

    /* ============================
     * HELPERS
     * ============================ */

    private function curl_post_json($url, $data, $timeout=8)
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($data)
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        return $resp;
    }

    private function aws_regions()
    {
        return [
            'us-east-1'=>'US East (N. Virginia)','us-east-2'=>'US East (Ohio)',
            'us-west-1'=>'US West (N. California)','us-west-2'=>'US West (Oregon)',
            'eu-west-1'=>'EU (Ireland)','eu-west-2'=>'EU (London)','eu-central-1'=>'EU (Frankfurt)',
            'ap-south-1'=>'Asia Pacific (Mumbai)','ap-southeast-1'=>'Asia Pacific (Singapore)',
            'ap-northeast-1'=>'Asia Pacific (Tokyo)'
        ];
    }

    private function get_saved_credentials()
    {
        if (!$this->db->table_exists('tblcspm_saved_credentials')) {
            $this->db->query("CREATE TABLE IF NOT EXISTS `tblcspm_saved_credentials`(
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `provider` VARCHAR(20) NOT NULL,
                `label` VARCHAR(191) NOT NULL,
                `data` TEXT,
                `created_at` DATETIME
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        }
        return $this->db->order_by('id','DESC')->get('tblcspm_saved_credentials')->result_array();
    }

    private function save_credentials_snapshot($provider, $post)
    {
        $label = ($post['customer'] ?? 'Customer').' - '.($post['account_name'] ?? 'Account').' - '.strtoupper($provider);
        $this->db->insert('tblcspm_saved_credentials', [
            'provider'=>$provider,
            'label'=>$label,
            'data'=>json_encode($post),
            'created_at'=>date('Y-m-d H:i:s')
        ]);
    }
}
