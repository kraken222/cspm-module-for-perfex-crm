<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Aws_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Create immediate placeholder so UI shows "running"
    public function insert_scan_running($provider, $account_name, $region = 'all')
    {
        $scan_id = 'scan_'.uniqid().'_'.bin2hex(random_bytes(3));
        $row = [
            'scan_id' => $scan_id,
            'cloud_provider' => $provider,
            'account_name' => $account_name,
            'scan_status' => 'running',
            'total_checks' => 0,
            'compliant_checks' => 0,
            'non_compliant_checks' => 0,
            'compliance_percentage' => 0,
            'severity_breakdown' => json_encode(new stdClass()),
            'raw_results' => null,
            'started_at' => date('Y-m-d H:i:s'),
            'completed_at' => null,
            'region' => $region
        ];
        $this->db->insert('tblcspm_awsscan_results', $row);
        return $scan_id;
    }

    // Called by your Flask backend if you want PHP to finalize; safe to use elsewhere too
    public function finalize_scan($scan_id, $account_name, $summary, $findings)
    {
        $row = [
            'account_name' => $account_name,
            'scan_status'  => 'completed',
            'total_checks' => (int)($summary['total'] ?? 0),
            'compliant_checks' => (int)($summary['passed'] ?? 0),
            'non_compliant_checks' => (int)($summary['failed'] ?? 0),
            'compliance_percentage' => (float)(($summary['total'] ?? 0) ? (100.0*($summary['passed'] ?? 0)/max(1,$summary['total'])) : 100),
            'severity_breakdown' => json_encode($summary['by_severity'] ?? []),
            'raw_results' => json_encode($findings ?: []),
            'completed_at' => date('Y-m-d H:i:s')
        ];
        $this->db->where('scan_id',$scan_id)->update('tblcspm_awsscan_results',$row);

        if (is_array($findings)) {
            foreach ($findings as $f) {
                $res = $f['resources'][0] ?? [];
                $this->db->insert('tblcspm_awscompliance_findings', [
                    'scan_id'      => $scan_id,
                    'finding_id'   => $f['finding_info']['uid'] ?? uniqid('f_'),
                    'check_name'   => $f['finding_info']['title'] ?? 'Unknown Check',
                    'check_description' => $f['message'] ?? '',
                    'status'       => ($f['status_code'] ?? '') === 'FAIL' ? 'FAIL' : 'PASS',
                    'severity'     => $f['severity'] ?? 'MEDIUM',
                    'resource_id'  => $res['uid'] ?? ($res['data']['arn'] ?? ''),
                    'resource_type'=> $res['type'] ?? 'Unknown',
                    'region'       => $res['region'] ?? 'global',
                    'remediation'  => $f['remediation']['desc'] ?? '',
                    'evidence'     => json_encode($f),
                    'found_at'     => isset($f['time_dt']) ? date('Y-m-d H:i:s', strtotime($f['time_dt'])) : date('Y-m-d H:i:s')
                ]);
            }
        }
    }
}
