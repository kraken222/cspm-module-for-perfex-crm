<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gcp_model extends CI_Model
{
    private $scoutsuite = '/usr/local/bin/scoutsuite';
    private $report_root = '/var/www/html/cspm_reports/gcp';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        if (!is_dir($this->report_root)) { @mkdir($this->report_root,0755,true); }
    }

    public function start_scan($service_account_json, $account_name='GCP Project')
    {
        $scan_id = 'gcp_'.uniqid();
        $this->insert_running_row($scan_id, $account_name);

        $dir = $this->report_root . '/' . $scan_id;
        @mkdir($dir,0755,true);

        // Save svc account json to a file (if provided)
        $keyfile = null;
        if (!empty($service_account_json)) {
            $keyfile = $dir.'/key.json';
            @file_put_contents($keyfile, $service_account_json);
            @chmod($keyfile,0600);
        }

        $cmd = escapeshellcmd($this->scoutsuite) . ' gcp --cli --report-dir '.escapeshellarg($dir);
        if ($keyfile) {
            $cmd .= ' --service-account-file '.escapeshellarg($keyfile);
            $env = ['GOOGLE_APPLICATION_CREDENTIALS' => $keyfile];
        } else {
            $env = [];
        }

        $this->spawn_background($cmd, $dir.'/stdout.log', $dir.'/stderr.log', $env, function() use ($scan_id,$dir,$account_name){
            $this->finalize_from_scoutsuite($scan_id, $dir, 'gcp', $account_name);
        });

        return $scan_id;
    }

    private function insert_running_row($scan_id, $account)
    {
        $this->db->insert('tblcspm_awsscan_results', [
            'scan_id'=>$scan_id,'cloud_provider'=>'gcp','account_name'=>$account,
            'scan_status'=>'running','total_checks'=>0,'compliant_checks'=>0,'non_compliant_checks'=>0,
            'compliance_percentage'=>0,'severity_breakdown'=>json_encode(new stdClass()),
            'started_at'=>date('Y-m-d H:i:s'),'completed_at'=>null,'region'=>'global'
        ]);
    }

    private function finalize_from_scoutsuite($scan_id, $dir, $provider, $account_name)
    {
        $json = $this->find_report_json($dir);
        if (!$json || !file_exists($json)) {
            $this->db->where('scan_id',$scan_id)->update('tblcspm_awsscan_results',[
                'scan_status'=>'failed','completed_at'=>date('Y-m-d H:i:s')
            ]);
            return;
        }
        $raw = @file_get_contents($json);
        $decoded = json_decode($raw,true);
        $total=0;$failed=0;$passed=0;$bysev=[];
        if (isset($decoded['checks']) && is_array($decoded['checks'])) {
            foreach ($decoded['checks'] as $check) {
                $total++;
                $sev = strtolower($check['level'] ?? 'medium');
                $bysev[$sev] = ($bysev[$sev] ?? 0) + 1;
                if (($check['status'] ?? '') === 'fail') $failed++; else $passed++;
            }
        }
        $this->db->where('scan_id',$scan_id)->update('tblcspm_awsscan_results',[
            'scan_status'=>'completed',
            'total_checks'=>$total,
            'compliant_checks'=>$passed,
            'non_compliant_checks'=>$failed,
            'compliance_percentage'=> $total? (100.0*$passed/$total) : 100,
            'severity_breakdown'=>json_encode($bysev),
            'raw_results'=>$raw,
            'completed_at'=>date('Y-m-d H:i:s')
        ]);
    }

    private function find_report_json($dir)
    {
        $candidates = glob($dir.'/*report*.json');
        return $candidates ? $candidates[0] : null;
    }

    private function spawn_background($cmd, $stdout, $stderr, $env, $on_finish)
    {
        $descriptors = [
            1 => ['file',$stdout,'a'],
            2 => ['file',$stderr,'a'],
        ];
        $env = array_merge($_ENV, $_SERVER, $env);
        $process = proc_open($cmd.' > '.escapeshellarg($stdout).' 2> '.escapeshellarg($stderr).' &', [], $pipes, null, $env);
        if (is_resource($process)) { proc_close($process); }
        // See the Azure comment regarding real async callbacks.
    }
}
